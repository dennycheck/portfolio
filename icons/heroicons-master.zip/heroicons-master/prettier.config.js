module.exports = {
  singleQuote: true,
  semi: false,
  printWidth: 100,
}
