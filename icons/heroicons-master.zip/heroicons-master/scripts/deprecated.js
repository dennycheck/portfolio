module.exports.deprecated = [
  'arrow-left-on-rectangle.svg',
  'arrow-right-on-rectangle.svg',
  'arrow-small-down.svg',
  'arrow-small-left.svg',
  'arrow-small-right.svg',
  'arrow-small-up.svg',
  'minus-small.svg',
  'plus-small.svg',
]
